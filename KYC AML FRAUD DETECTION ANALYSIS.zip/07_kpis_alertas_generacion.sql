-- =====================================================================
-- 07_kpis_alertas_generacion.sql (MySQL) -- SOLO USO INTERNO
-- Este archivo NO se entrega a Jorge. Es la traduccion a MySQL de la
-- logica de deteccion (las 7 vistas de alertas + consolidada) que
-- existe UNICAMENTE para poder generar de forma realista la tabla
-- historica casos_revision_kyc (08_generar_casos_revision.sql).
--
-- Jorge escribira sus propias 7 queries de deteccion desde cero, mas
-- adelante, guiado paso a paso -- ese es el contenido "de entrevista"
-- real del proyecto. Esto es solo infraestructura de generacion de
-- datos, igual que los scripts 03-06.
-- =====================================================================
USE kyc_aml_portafolio;

-- ---------------------------------------------------------------------
-- 1) ESTRUCTURACION / SMURFING
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_alerta_estructuracion AS
WITH candidatas AS (
    SELECT transaccion_id, cuenta_id, fecha_hora, monto_mxn
    FROM transacciones
    WHERE tipo_transaccion = 'Deposito Efectivo' AND monto_mxn BETWEEN 100000 AND 149999
),
ventanas AS (
    SELECT c1.cuenta_id, c1.transaccion_id, c1.fecha_hora,
           COUNT(*) AS depositos_en_ventana,
           SUM(c2.monto_mxn) AS monto_total_ventana
    FROM candidatas c1
    JOIN candidatas c2
      ON c2.cuenta_id = c1.cuenta_id
     AND c2.fecha_hora BETWEEN c1.fecha_hora - INTERVAL 10 DAY AND c1.fecha_hora + INTERVAL 10 DAY
    GROUP BY c1.cuenta_id, c1.transaccion_id, c1.fecha_hora
)
SELECT
    cl.cliente_id, cl.nombre_completo, cl.ciudad, v.cuenta_id,
    MAX(v.depositos_en_ventana) AS max_depositos_ventana_10d,
    MAX(v.monto_total_ventana) AS monto_max_acumulado,
    MIN(v.fecha_hora) AS primera_deteccion
FROM ventanas v
JOIN cuentas cu ON cu.cuenta_id = v.cuenta_id
JOIN clientes cl ON cl.cliente_id = cu.cliente_id
WHERE v.depositos_en_ventana >= 5
GROUP BY cl.cliente_id, cl.nombre_completo, cl.ciudad, v.cuenta_id;

-- ---------------------------------------------------------------------
-- 2) TRANSACCIONES CON PAISES SANCIONADOS (OFAC)
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_alerta_pais_sancionado AS
SELECT
    cl.cliente_id, cl.nombre_completo, cl.ciudad, t.cuenta_id, t.transaccion_id,
    t.fecha_hora, t.monto_mxn, po.nombre_pais AS pais_origen, pd.nombre_pais AS pais_destino
FROM transacciones t
JOIN paises po ON po.pais_id = t.pais_origen_id
JOIN paises pd ON pd.pais_id = t.pais_destino_id
JOIN cuentas cu ON cu.cuenta_id = t.cuenta_id
JOIN clientes cl ON cl.cliente_id = cu.cliente_id
WHERE po.es_sancionado_ofac = 1 OR pd.es_sancionado_ofac = 1;

-- ---------------------------------------------------------------------
-- 3) MONTO INUSUAL VS. HISTORICO DEL CLIENTE (z-score)
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_alerta_monto_inusual AS
WITH stats AS (
    SELECT cuenta_id, AVG(monto_mxn) AS promedio, STDDEV_POP(monto_mxn) AS desviacion, COUNT(*) AS n_transacciones
    FROM transacciones
    GROUP BY cuenta_id
    HAVING COUNT(*) >= 5
)
SELECT
    cl.cliente_id, cl.nombre_completo, t.cuenta_id, t.transaccion_id, t.fecha_hora, t.monto_mxn,
    ROUND(s.promedio, 2) AS promedio_historico_cuenta,
    ROUND((t.monto_mxn - s.promedio) / NULLIF(s.desviacion, 0), 2) AS z_score
FROM transacciones t
JOIN stats s ON s.cuenta_id = t.cuenta_id
JOIN cuentas cu ON cu.cuenta_id = t.cuenta_id
JOIN clientes cl ON cl.cliente_id = cu.cliente_id
WHERE s.desviacion > 0 AND (t.monto_mxn - s.promedio) / s.desviacion > 4.5;

-- ---------------------------------------------------------------------
-- 4) VELOCIDAD -- 5+ transacciones en menos de 15 minutos
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_alerta_velocidad AS
WITH ventanas AS (
    SELECT t1.cuenta_id, t1.transaccion_id, t1.fecha_hora,
           COUNT(*) AS transacciones_en_ventana
    FROM transacciones t1
    JOIN transacciones t2
      ON t2.cuenta_id = t1.cuenta_id
     AND t2.fecha_hora BETWEEN t1.fecha_hora - INTERVAL 15 MINUTE AND t1.fecha_hora + INTERVAL 15 MINUTE
    GROUP BY t1.cuenta_id, t1.transaccion_id, t1.fecha_hora
)
SELECT
    cl.cliente_id, cl.nombre_completo, v.cuenta_id,
    MAX(v.transacciones_en_ventana) AS max_transacciones_ventana_15min,
    MIN(v.fecha_hora) AS primera_deteccion
FROM ventanas v
JOIN cuentas cu ON cu.cuenta_id = v.cuenta_id
JOIN clientes cl ON cl.cliente_id = cu.cliente_id
WHERE v.transacciones_en_ventana >= 5
GROUP BY cl.cliente_id, cl.nombre_completo, v.cuenta_id;

-- ---------------------------------------------------------------------
-- 5) SOCIOS / UBO EN LISTA NEGRA
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_alerta_ubo_lista_negra AS
SELECT
    cl.cliente_id, cl.nombre_completo AS razon_social, s.socio_id, s.nombre_socio,
    s.porcentaje_participacion, s.es_beneficiario_final_ubo, p.nombre_pais AS nacionalidad_socio
FROM personas_morales_socios s
JOIN clientes cl ON cl.cliente_id = s.cliente_id
JOIN paises p ON p.pais_id = s.pais_nacionalidad_id
WHERE s.en_lista_negra = 1;

-- ---------------------------------------------------------------------
-- 6) POSIBLE RED DE PRESTANOMBRES
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_alerta_prestanombres AS
WITH dispositivos_compartidos AS (
    SELECT dispositivo_id, COUNT(DISTINCT cliente_id) AS clientes_compartiendo
    FROM contacto_dispositivo_cliente
    GROUP BY dispositivo_id
    HAVING COUNT(DISTINCT cliente_id) > 1
),
flujo_cliente AS (
    SELECT cu.cliente_id, SUM(t.monto_mxn) AS flujo_total_12m
    FROM transacciones t JOIN cuentas cu ON cu.cuenta_id = t.cuenta_id
    WHERE t.fecha_hora > DATE_SUB(NOW(), INTERVAL 365 DAY)
    GROUP BY cu.cliente_id
)
SELECT
    cl.cliente_id, cl.nombre_completo, cl.ingreso_mensual_declarado_mxn,
    cdc.dispositivo_id, dc.clientes_compartiendo,
    ROUND(f.flujo_total_12m, 2) AS flujo_transaccional_12m,
    ROUND(f.flujo_total_12m / NULLIF(cl.ingreso_mensual_declarado_mxn * 12, 0), 2) AS veces_ingreso_anual_declarado
FROM contacto_dispositivo_cliente cdc
JOIN dispositivos_compartidos dc ON dc.dispositivo_id = cdc.dispositivo_id
JOIN clientes cl ON cl.cliente_id = cdc.cliente_id
LEFT JOIN flujo_cliente f ON f.cliente_id = cl.cliente_id;

-- ---------------------------------------------------------------------
-- 7) CREDENTIAL STUFFING / FUERZA BRUTA
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_alerta_credential_stuffing AS
WITH fallidos AS (
    SELECT * FROM intentos_acceso WHERE exitoso = 0
),
ventanas AS (
    SELECT f1.cliente_id, f1.intento_id, f1.fecha_hora,
           COUNT(*) AS intentos_en_ventana,
           COUNT(DISTINCT f2.ip_origen) AS ips_distintas
    FROM fallidos f1
    JOIN fallidos f2
      ON f2.cliente_id = f1.cliente_id
     AND f2.fecha_hora BETWEEN f1.fecha_hora - INTERVAL 20 MINUTE AND f1.fecha_hora + INTERVAL 20 MINUTE
    GROUP BY f1.cliente_id, f1.intento_id, f1.fecha_hora
),
resumen AS (
    SELECT cl.cliente_id, cl.nombre_completo,
           MAX(v.intentos_en_ventana) AS max_intentos_fallidos_ventana_20min,
           MAX(v.ips_distintas) AS max_ips_distintas,
           MIN(v.fecha_hora) AS primera_deteccion
    FROM ventanas v
    JOIN clientes cl ON cl.cliente_id = v.cliente_id
    WHERE v.intentos_en_ventana >= 8 AND v.ips_distintas >= 3
    GROUP BY cl.cliente_id, cl.nombre_completo
)
SELECT
    r.*,
    EXISTS (
        SELECT 1 FROM intentos_acceso ia
        WHERE ia.cliente_id = r.cliente_id AND ia.exitoso = 1
          AND ia.fecha_hora BETWEEN r.primera_deteccion AND r.primera_deteccion + INTERVAL 1 DAY
    ) AS hubo_acceso_exitoso_posterior
FROM resumen r;

-- ---------------------------------------------------------------------
-- VISTA CONSOLIDADA (una fila por alerta detectada)
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_alertas_consolidadas AS
SELECT 'Cliente' AS tipo_entidad, cliente_id AS entidad_id, cliente_id,
       'Estructuracion' AS tipo_alerta,
       CONCAT('Cuenta ', cuenta_id, ': ', max_depositos_ventana_10d, ' depositos en efectivo en ventana de 10 dias, $', monto_max_acumulado, ' MXN acumulados') AS detalle,
       primera_deteccion AS fecha_deteccion, 'Alta' AS severidad_sugerida
FROM vw_alerta_estructuracion
UNION ALL
SELECT 'Cliente', cliente_id, cliente_id, 'Pais Sancionado OFAC',
       CONCAT('Transaccion ', transaccion_id, ' de $', monto_mxn, ' MXN con ', pais_destino),
       fecha_hora, 'Critica'
FROM vw_alerta_pais_sancionado
UNION ALL
SELECT 'Cliente', cliente_id, cliente_id, 'Monto Inusual',
       CONCAT('Transaccion ', transaccion_id, ' de $', monto_mxn, ' MXN (z-score ', z_score, ' vs promedio $', promedio_historico_cuenta, ')'),
       fecha_hora, 'Media'
FROM vw_alerta_monto_inusual
UNION ALL
SELECT 'Cliente', cliente_id, cliente_id, 'Velocidad Alta',
       CONCAT('Cuenta ', cuenta_id, ': ', max_transacciones_ventana_15min, ' transacciones en 15 minutos'),
       primera_deteccion, 'Media'
FROM vw_alerta_velocidad
UNION ALL
SELECT 'Socio', socio_id, cliente_id, 'UBO en Lista Negra',
       CONCAT('Socio "', nombre_socio, '" (', porcentaje_participacion, '%) nacionalidad ', nacionalidad_socio),
       NOW(), 'Critica'
FROM vw_alerta_ubo_lista_negra
UNION ALL
SELECT 'Cliente', cliente_id, cliente_id, 'Posible Prestanombres',
       CONCAT('Dispositivo ', dispositivo_id, ' compartido con ', (clientes_compartiendo - 1), ' cliente(s) mas; flujo = ', COALESCE(CAST(veces_ingreso_anual_declarado AS CHAR), 'N/D'), 'x el ingreso anual declarado'),
       NOW(), 'Alta'
FROM vw_alerta_prestanombres
UNION ALL
SELECT 'Cliente', cliente_id, cliente_id, 'Credential Stuffing / Fuerza Bruta',
       CONCAT(max_intentos_fallidos_ventana_20min, ' intentos fallidos desde ', max_ips_distintas, ' IPs en 20 min',
              CASE WHEN hubo_acceso_exitoso_posterior THEN ' -- HUBO acceso exitoso despues (posible cuenta comprometida)' ELSE '' END),
       primera_deteccion, CASE WHEN hubo_acceso_exitoso_posterior THEN 'Critica' ELSE 'Alta' END
FROM vw_alerta_credential_stuffing;
